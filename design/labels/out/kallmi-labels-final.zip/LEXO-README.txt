KALLMI - ETIKETAT E VAJIT TE ULLIRIT / OLIVE OIL LABELS
=======================================================

Skedaret per printim (3 mm bleed nga cdo ane, TrimBox i vendosur, tekstet ne vija):

1. kallmi-oil-750ml-PRESS.pdf    Shishe Marasca 750 ml   52 x 150 mm   para + mbrapa
2. kallmi-oil-500ml-PRESS.pdf    Shishe Marasca 500 ml   48 x 140 mm   para + mbrapa
3. kallmi-oil-250ml-PRESS.pdf    Shishe Marasca 250 ml   38 x 110 mm   para + mbrapa
4. kallmi-oil-3l-PRESS.pdf       Bidon 3 l, para         120 x 170 mm
5. kallmi-oil-3l-side-PRESS.pdf  Bidon 3 l, anash        48 x 170 mm

Ngjyrat (RGB ne PDF, ju lutem konvertojini me profilin tuaj):
- E zeza: rich black, rreth C60 M40 Y40 K100, jo mbi 300% boje
- Ari: #C4A862 - ju lutem propozoni Pantone-n me te afert, ose oferte me folio ari (hot foil)

Letra: sintetike (PP) ose me laminim mat - etiketat kane kontakt me vaj.
Barkodi i 250 ml eshte i shkurtuar me qellim.
Ju lutem nje prove te printuar para prodhimit, sidomos per tekstin e vogel ne sfond te zi.

kallmi-oil-family-preview.png = pamje e te gjitha etiketave (jo per printim).
